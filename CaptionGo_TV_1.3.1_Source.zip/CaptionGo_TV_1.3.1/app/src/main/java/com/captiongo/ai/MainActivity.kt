package com.captiongo.ai

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var urlBox: EditText
    private lateinit var status: TextView
    private var uploadCallback: ValueCallback<Array<Uri>>? = null
    private var fullscreenView: View? = null
    private var fullscreenCallback: WebChromeClient.CustomViewCallback? = null

    companion object { private const val FILE_PICKER = 2001 }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        setContentView(R.layout.activity_main)

        web = findViewById(R.id.browser)
        urlBox = findViewById(R.id.urlBox)
        status = findViewById(R.id.statusText)
        val go = findViewById<Button>(R.id.goButton)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = true
        web.settings.javaScriptCanOpenWindowsAutomatically = false
        web.settings.allowFileAccess = false
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                return !(uri.scheme == "https" || uri.scheme == "http")
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                uploadCallback?.onReceiveValue(null)
                uploadCallback = filePathCallback
                val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "*/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                return try {
                    startActivityForResult(intent, FILE_PICKER)
                    true
                } catch (_: Exception) {
                    uploadCallback = null
                    false
                }
            }

            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (view == null) return
                fullscreenView = view
                fullscreenCallback = callback
                setContentView(view)
            }

            override fun onHideCustomView() {
                fullscreenView = null
                fullscreenCallback?.onCustomViewHidden()
                fullscreenCallback = null
                setContentView(R.layout.activity_main)
                web = findViewById(R.id.browser)
                urlBox = findViewById(R.id.urlBox)
                status = findViewById(R.id.statusText)
                setupAfterFullscreen()
            }
        }

        go.setOnClickListener { openAddress() }
        urlBox.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) {
                openAddress(); true
            } else false
        }

        web.loadUrl("https://example.com")
        urlBox.setText("https://example.com")
        urlBox.setOnFocusChangeListener { _, hasFocus ->
            status.text = if (hasFocus) "लिंक लिखें और GO चुनें" else
                "Remote: arrows से चलें • OK से चुनें • Back से वापस जाएँ"
        }
        web.requestFocus()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupAfterFullscreen() {
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {}
        findViewById<Button>(R.id.goButton).setOnClickListener { openAddress() }
        web.requestFocus()
    }

    private fun openAddress() {
        var address = urlBox.text.toString().trim()
        if (address.isEmpty()) return
        if (!address.startsWith("http://") && !address.startsWith("https://")) {
            address = "https://$address"
        }
        val uri = Uri.parse(address)
        if (uri.scheme != "https" && uri.scheme != "http") {
            status.text = "केवल http/https वेबसाइट समर्थित हैं"
            return
        }
        urlBox.setText(address)
        web.loadUrl(address)
        web.requestFocus()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (fullscreenView != null && keyCode == KeyEvent.KEYCODE_BACK) {
            (web.webChromeClient as? WebChromeClient)?.onHideCustomView()
            return true
        }
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (::web.isInitialized && web.canGoBack()) {
                web.goBack()
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == FILE_PICKER) {
            val result = if (resultCode == Activity.RESULT_OK && data?.data != null) {
                arrayOf(data.data!!)
            } else null
            uploadCallback?.onReceiveValue(result)
            uploadCallback = null
        }
    }

    override fun onDestroy() {
        if (::web.isInitialized) web.destroy()
        super.onDestroy()
    }
}
