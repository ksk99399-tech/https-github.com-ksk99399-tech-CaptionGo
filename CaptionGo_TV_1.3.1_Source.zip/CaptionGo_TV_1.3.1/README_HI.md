# CaptionGo TV 1.3.1 — Starter Project

यह Android TV-friendly browser shell है। इसमें WebView, URL bar, TV D-pad focus, Back navigation, वेबसाइट के file-upload input और HTML5 fullscreen video का शुरुआती सपोर्ट है।

## जरूरी सीमाएँ
- यह अभी पूरा AI Audio-to-Subtitle अनुवादक नहीं है।
- किसी भी वेबसाइट के अंदर चल रहे वीडियो का ऑडियो हर स्थिति में ऐप द्वारा पढ़ा नहीं जा सकता। DRM/protected streams और cross-origin restrictions के कारण ऐसा अक्सर संभव नहीं होता।
- AI transcription/translation के लिए अलग speech-to-text और translation service/backend जोड़ना होगा। “सभी भाषाएँ और पूरी तरह मुफ्त” की गारंटी किसी सेवा में नहीं है।
- यह सामान्य वैध वेबसाइटों के लिए ब्राउज़र ढाँचा है; वेबसाइट की अपनी शर्तों और कॉपीराइट का पालन करें।

## Android Studio से APK
1. Android Studio में इस पूरे फ़ोल्डर को Open करें।
2. Gradle Sync पूरा होने दें।
3. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
4. APK `app/build/outputs/apk/debug/app-debug.apk` में मिलेगा।
5. TV पर टेस्ट करें। TV पर unknown-source install अनुमति केवल भरोसेमंद APK के लिए दें।

## मोबाइल से ऑनलाइन बिल्ड (GitHub Actions)
1. GitHub पर नया repository बनाएं।
2. इस ZIP को extract करके सभी फाइलें repository में upload करें।
3. `.github/workflows/build.yml` नाम की फाइल जोड़ें (नीचे वाला workflow)।
4. GitHub repository के Actions tab में workflow run करें।
5. Run पूरा होने पर `captiongo-tv-debug-apk` artifact डाउनलोड करें।

## GitHub Actions workflow
नीचे की सामग्री `.github/workflows/build.yml` में रखें:

```yaml
name: Build CaptionGo TV APK
on:
  workflow_dispatch:
  push:
    branches: [ main ]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - uses: android-actions/setup-android@v3
      - uses: gradle/actions/setup-gradle@v4
      - name: Build debug APK
        run: gradle assembleDebug
      - uses: actions/upload-artifact@v4
        with:
          name: captiongo-tv-debug-apk
          path: app/build/outputs/apk/debug/app-debug.apk
```

GitHub-hosted runners और Actions की मुफ्त उपलब्धता account limits/usage पर निर्भर करती है।
